<?php
	//mengatur zona waktu agar sesuai dengan waktu lokal
	date_default_timezone_set("Asia/Jakarta");

	//memanggil file koneksi yang ada di dalam folder config
		include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>KYUNGSOO DRINK</title>
	<style type="text/css">
	
	.judul{
		font-size: 22px;
		text-align: center;
	}
	table{
		font-size: 18px;
	}

	.abc{
		font-size: 18px;
		text-align: right;
		padding-right: 5%;
	}

	</style>
</head>
<body>
	<p class="judul">KYUNGSOO DRINK<br>
	Jalan Raya Pasir Angin<br>
	0895395584288<br></p>
	<hr>
	<p class="judul">LAPORAN DATA PEMBELIAN KYUNGSOO DRINK</p>
	<table border="1" align="center">
			<tr>
		        <td>Nama</td>
		        <td>Harga</td>
		        <td>Jumlah</td>
		        <td>Harga Total</td>
		        <td>Bayar</td>
		        <td>Kembalian</td>
			</tr>
			
			<?php 
			//perintah sql tampil data
				$sql = "SELECT * FROM tb_transaksis";
			//mengeksekusi perintah sql di atas
				$query = mysqli_query($koneksi, $sql);
			//ini untuk menampung data
				while($data = mysqli_fetch_array($query)){
			 ?>

			<tr>
				<td><?= $data['nama_minuman'] ?></td>
		        <td> <?= $data['harga'] ?></td>
		        <td> <?= $data['jumlah'] ?></td>
		        <td> <?= $data['hargatot'] ?></td>
		        <td> <?= $data['bayar'] ?></td>
		        <td> <?= $data['kembalian'] ?></td>
			</tr>
			<?php }?>
		</table>
		<br>
</body>
</html>
<script>
	window.print();
</script>