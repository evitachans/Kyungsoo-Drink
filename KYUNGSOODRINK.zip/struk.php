<?php
	//mengatur zona waktu agar sesuai dengan waktu lokal
	date_default_timezone_set("Asia/Jakarta");

	//memanggil file koneksi yang ada di dalam folder config
		include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>KYUNGSOO DRINK</title>
	<style type="text/css">
	.str{
		border: 1px solid black;
		width: 300px;
		padding-left: 20px;
		padding-right: 20px;
		padding-bottom: 15px;
	}

	.judul{
		font-size: 22px;
	}

	p{
		font-size: 18px;
	}
	table{
		font-size: 18px;
	}

	</style>
</head>
<body>
	<div class="str">
	<p class="judul"><center>KYUNGSOO DRINK</center><br>
	<center>Jalan Raya Pasir Angin</center><br>
	<center>0895395585288</center></p>
	<hr>
		<?php 
			$tanggal = date('Y-m-d');
		//perintah sql tampil data
			$sql = "SELECT * FROM tb_transaksis WHERE id='$_GET[id]'";
		//mengeksekusi perintah sql di atas
			$query = mysqli_query($koneksi, $sql);
		//ini untuk menampung data
			while($data = mysqli_fetch_array($query)){
		 ?>
		<table>
		 	<tr>
		 		<td>Tanggal</td>
		 		<td>:</td>
		 		<td><?php echo $tanggal; ?></td>
		 	</tr>
		 </table>
		 <hr>
		 <table>
		 	<tr>
		 		<td>Nama Minuman</td>
		 		<td>:</td>
		 		<td><?php echo $data['nama_minuman']; ?></td>
		 	</tr>
		 	<tr>
		 		<td>Harga Minuman</td>
		 		<td>:</td>
		 		<td>Rp <?php echo $data['harga']; ?></td>
		 	</tr>
		 	<tr>
		 		<td>Jumlah Minuman</td>
		 		<td>:</td>
		 		<td><?php echo $data['jumlah']; ?></td>
		 	</tr>
		</table>
		<hr>
		<table>
			<tr>
		 		<td>Total Harga Minuman</td>
		 		<td>:</td>
		 		<td>Rp <?php echo $data['hargatot']; ?></td>
		 	</tr>
		 	<tr>
		 		<td>Tunai</td>
		 		<td>:</td>
		 		<td>Rp <?php echo $data['bayar']; ?></td>
		 	</tr>
		 	<tr>
		 		<td>Kembali</td>
		 		<td>:</td>
		 		<td>Rp <?php echo $data['kembalian']; ?></td>
		 	</tr>
		</table>
		<?php }?>
		<hr>
		<p>Terima Kasih Telah Berbelanja di Kyungsoo Drink!<br>
		</p>
	</div>
</body>
</html>
<script>
	window.print();
</script>